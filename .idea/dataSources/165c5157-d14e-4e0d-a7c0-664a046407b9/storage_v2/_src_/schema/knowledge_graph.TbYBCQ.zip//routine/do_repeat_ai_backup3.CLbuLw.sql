create
    definer = root@`%` procedure do_repeat_ai_backup3(IN page int)
BEGIN
		DECLARE start_num INT;
    # Loops WEEK by WEEK until NOW(). Change WEEK to something shorter like DAY if you still get the lock errors like.
    WHILE page <= 1300 DO
				SET start_num = (page-1)*10000;
				START TRANSACTION;
        # Do something
        INSERT INTO
            ai_journal_article_managed_backup3
            (
                id,
                field,
                author,
                headline,
								key_words,
								DE
            )
				SELECT
					b.id,
					b.field,
					b.author,
					b.headline,
					b.key_words,
					b.DE 
				FROM
					( SELECT id FROM ai_journal_article_managed ORDER BY id LIMIT start_num, 10000 ) a
					LEFT JOIN ai_journal_article_managed b ON a.id = b.id;
				
				COMMIT WORK;
        # Increment
        SET page = page + 1;

    END WHILE;

END;

