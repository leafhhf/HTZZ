create
    definer = root@`%` procedure pro_ai_industry_reports()
BEGIN  
          
                 insert into knowledge_graph.ai_industry_reports(industry,erjiindustry,detail_field,title,reporttime,url,source,hangye,pdfurl)
         select industry,erjiindustry,detail_field,title,reporttime,url,source,industryName,pdfurl
from ai_industry_reports_mid where industry is not null and  title not in (select title from knowledge_graph.ai_industry_reports) order by reporttime;
        
          commit;
          
          END;

