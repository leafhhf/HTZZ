create
    definer = root@`%` procedure pro_ai_news_information1()
BEGIN  
          
                 insert into knowledge_graph.ai_news_information(industry,title, keyword, type, listpic1, url, reporttime,source,content)
          select case when source like '%数字经济%' then '数字经济' when source like '%区块链%' then '区块链' else '人工智能' end,title, keyword, type, listpic1, url, 
          case when reporttime like '%前%' then substr(sysdate(),1,10) else date_format(reporttime, '%Y-%m-%d')  end reporttime,source,content from 
          knowledge_graph.ai_news_information_mid where title not in (select title from knowledge_graph.ai_news_information);
        
          commit;
          
          END;

