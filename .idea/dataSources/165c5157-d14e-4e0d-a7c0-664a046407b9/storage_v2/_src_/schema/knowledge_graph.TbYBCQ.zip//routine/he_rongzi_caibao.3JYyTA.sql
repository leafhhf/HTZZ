create
    definer = root@`%` procedure he_rongzi_caibao()
BEGIN
	#Routine body goes here...
	DELETE FROM ai_rongzi_caibao;
	INSERT INTO ai_rongzi_caibao(industry, shortname, companyname, areacode, YEAR, yingyeshouru, yingyelirun, lirunzonge, jinglirun, zichanzongji, fuzhaiheji, gudongquanyiheji, personinvestment, funding, RENYUANSHU, ZHUYINGYEWU, GONGSILEIXING, YFZCZBHJE)
	SELECT industry, shortname, companyname, areacode, YEAR, yingyeshouru, yingyelirun, lirunzonge, jinglirun, zichanzongji, fuzhaiheji, gudongquanyiheji, personinvestment, funding, RENYUANSHU, ZHUYINGYEWU, GONGSILEIXING, YFZCZBHJE FROM ai_hushen_caibao ;
	INSERT INTO ai_rongzi_caibao(industry,companyname,shortname, invest_time, invest_year, round, financing_amount, invst_institute, invest_url, invest_headline, com_tag, field, LEI_XING, chu_rang_bi_li, gu_zhi, financing_amount_yssj, source
)
	SELECT industry,com_registered_name,com_short_name, invest_time, invest_year, round, financing_amount, invst_institute, invest_url, invest_headline, com_tag, field, LEI_XING, chu_rang_bi_li, gu_zhi, financing_amount_yssj, source
 FROM ai_financing_amount ;

END;

