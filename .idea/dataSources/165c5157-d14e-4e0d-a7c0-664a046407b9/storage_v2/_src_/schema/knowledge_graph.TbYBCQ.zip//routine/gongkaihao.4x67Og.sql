create
    definer = root@`%` procedure gongkaihao()
BEGIN
insert into ai_patent_ditail_incopat_cn(field,erjiindustry,patent_num,gongkaihao,gongkaihao_new)
select distinct field,field,patent_num,patent_num,replace(patent_num,'-','') from ai_patent_ditail_managed 
where substr(inputdate,1,10) between '2020-11-17' and '2020-11-18' and country like '%中国%' and patent_num like '%;%';

insert into ai_patent_ditail_incopat_cn(field,erjiindustry,patent_num,gongkaihao,gongkaihao_new)
select distinct a.field,a.erjiindustry,a.patent_num,a.gongkaihao,replace(a.gongkaihao,'-','') from
(select t1.field,t1.field erjiindustry,t1.patent_num,SUBSTRING_INDEX(SUBSTRING_INDEX(t1.patent_num,';  ',t2.help_topic_id+1),';  ',-1) as gongkaihao
from ai_patent_ditail_managed t1 left join mysql.help_topic t2 
on t2.help_topic_id < (LENGTH(t1.patent_num)-LENGTH(REPLACE(t1.patent_num,';  ',''))+1)
where substr(inputdate,1,10) between '2020-11-17' and '2020-11-18' and country like '%中国%' and patent_num like '%;%') a;
END;

