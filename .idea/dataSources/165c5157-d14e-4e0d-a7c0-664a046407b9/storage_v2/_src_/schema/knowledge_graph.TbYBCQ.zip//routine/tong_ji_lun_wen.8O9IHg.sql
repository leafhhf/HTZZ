create
    definer = root@`%` procedure tong_ji_lun_wen()
BEGIN
	#Routine body goes here...
	declare nd int default 2019;
	declare i int default 0;			
       
 	declare cj int default 1;	
	
	
				SELECT YEAR(NOW()) into nd ;
				
				set cj = nd - 6;
				delete from tj_lunwen_by_ling_yu where nian_du >= cj;
				delete from tj_lunwen_by_sheng_fen where nian_du >= cj;
 
 
        -- 当s不等于1，也就是未遍历完时，会一直循环
        while i<6 do
             
            -- 写入地域统计表
						
						insert INTO tj_lunwen_by_sheng_fen (	sheng_fen,	nian_du,	fa_biao_shu	)
						SELECT
							jg.province AS NAME,	CONCAT('',nd) as nian_du,		COALESCE ( t.sl, 0 ) AS 	VALUE
							
						FROM
							(
							SELECT	a.province,count( 2 ) AS sl 	FROM ai_journal_article_managed a 
							WHERE	LEFT ( a.pub_year, 4 ) = nd
							GROUP BY	a.province 
							) t
							RIGHT JOIN ( SELECT q.sheng_fen AS province FROM d_qu_yu_sheng_fen q ) jg ON t.province = jg.province 
						ORDER BY 	jg.province ;
					/*	*/
						 -- 写入领域统计表
						 
						set cj= 2;
						insert INTO tj_lunwen_by_ling_yu(ling_yu,nian_du,fa_biao_shu,ling_yu_ceng_ji)

								SELECT
									jg.field AS NAME,CONCAT('',nd) as nian_du,	COALESCE ( t.sl, 0 ) AS  	VALUE, cj as lycj						
									
								FROM
									(
									SELECT		a.field,		count( 2 ) AS sl 	FROM		ai_journal_article_managed a 
									WHERE
										LEFT ( a.pub_year, 4 ) = nd
									GROUP BY		a.field 
									) t
									RIGHT JOIN ( select t.name as FIELD from  knowledge_center t where t.ceng_ji = cj ) jg ON t.field = jg.field 
								ORDER BY	jg.field ;							
								

								
						set cj= cj + 1 ;
						
						while cj < 6 do
								insert INTO tj_lunwen_by_ling_yu(ling_yu,nian_du,fa_biao_shu,ling_yu_ceng_ji)


							select t3.FIELD as name,CONCAT('',nd) as nian_du,count(t3.id ) as value, cj as lycj	 from (	
						select t1.FIELD,a.id as id from ( SELECT t.NAME AS FIELD FROM knowledge_center t) t1 
							left join (select id ,type2, pub_year from ai_journal_article_managed  where pub_year = nd ) a  on  a.type2 like CONCAT('%',SUBSTRING_INDEX(t1.FIELD,'-',-1),'%') 
						) t3 ,knowledge_center t4 where t3.FIELD = t4.`name` and t4.ceng_ji = cj group by t3.FIELD    ;
				
							set cj= cj + 1 ;
						end while;
					set i = i+1;
					set nd = nd-1 ;
        end while;
	
   -- 关闭游标
   
		
END;

