create
    definer = root@`%` procedure ji_suan_keywords_zb()
BEGIN
	#Routine body goes here...
	declare s int default 0;
	declare kwdid int default 0;
	declare kwd VARCHAR(100);
	
	declare lws int default 0;
	declare yys int default 0;
	
	DECLARE report CURSOR FOR  select  t.id,t.key_word from ai_word_cloud_data t where t.feild='人工智能' and t.bei_yin_pin_ci is null order by t.num desc LIMIT 20  ;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET s=1;
	
	 -- 打开游标
    open report;
 
       				
				-- 将游标中的值赋值给变量，注意：变量名不要和返回的列名同名，变量顺序要和sql结果列的顺序一致
        fetch report into kwdid,kwd;
 
        -- 当s不等于1，也就是未遍历完时，会一直循环
        while s<>1 do
             
            -- 执行业务逻辑
						select count(2), sum(t.quoted_num1) into lws,yys from ai_journal_article_managed t where t.key_words like CONCAT('%',kwd,'%');
						
						update  ai_word_cloud_data t  set t.lun_wen_shu = lws ,t.bei_yin_pin_ci = yys where t.id = kwdid ;          
 
            -- 当s等于1时表明遍历以完成，退出循环
            fetch report into  kwdid,kwd;
        end while;
	
   -- 关闭游标
    close report;
		
END;

