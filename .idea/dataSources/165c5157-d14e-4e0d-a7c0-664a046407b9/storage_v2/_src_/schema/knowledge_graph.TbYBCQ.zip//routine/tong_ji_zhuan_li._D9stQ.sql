create
    definer = root@`%` procedure tong_ji_zhuan_li()
BEGIN
	#Routine body goes here...
	declare nd int default 2019;
	declare i int default 0;	
	declare cj int default 1;	
	
        SELECT YEAR(NOW()) into nd ;
				
				set cj = nd - 6;
				delete from tj_zhuan_li_by_guo_jia where nian_du >= cj;
				delete from tj_zhuan_li_by_ling_yu where nian_du >= cj;
 
        -- 当i等于6，统计近六年
        while i<=6 do
             
            -- 写入地域统计表
						insert INTO tj_zhuan_li_by_guo_jia (	guo_jia,	nian_du,	sheng_qing_shu	)

					select name ,CONCAT('',nd) as nian_du,sum(value ) as value from (
									select  jg.country as name, COALESCE (t.sl,0) as value
											from (
											SELECT 	a.country ,count(2) AS sl  FROM ai_patent_ditail_managed a
											where  left(a.ZHUCE_RIQI,4) = nd  group by a.country
											) t
											RIGHT JOIN (  select jg.name as country from d_guo_jia jg   ) jg ON  t.country like CONCAT ('%',jg.country ,'%')
										 ) t GROUP BY t.name  order by value desc  
					  ;
						 -- 写入领域统计表
					set cj= 2;
					
					insert INTO tj_zhuan_li_by_ling_yu(ling_yu,nian_du,sheng_qing_shu,ling_yu_ceng_ji)

								 select  jg.field as name,CONCAT('',nd) as nian_du, COALESCE (t.sl,0) as value ,cj  
									from (
											SELECT 	a.field ,count(2) AS sl
											FROM 	ai_patent_ditail_managed a
											where  left(a.ZHUCE_RIQI,4) = nd
											group by a.field
									) t
									RIGHT JOIN (
										select t.name as FIELD from  knowledge_center t where t.ceng_ji = cj
									) jg on t.field = jg.field;
					set cj= cj + 1 ;		
					
					while cj < 6 do
						insert INTO tj_zhuan_li_by_ling_yu(ling_yu,nian_du,sheng_qing_shu,ling_yu_ceng_ji)
							
								select t3.FIELD as name,CONCAT('',nd) as nian_du,count(t3.id ) as value ,cj   from (	
								select t1.FIELD,a.id as id from ( SELECT t.NAME AS FIELD FROM knowledge_center t) t1 
									left join (select id ,type2, LEFT(ZHUCE_RIQI,4)  from ai_patent_ditail_managed  where LEFT(ZHUCE_RIQI,4) = nd ) a  on  a.type2 like CONCAT('%',SUBSTRING_INDEX(t1.FIELD,'-',-1),'%') 
								) t3 ,knowledge_center t4 where t3.FIELD = t4.`name` and t4.ceng_ji = cj group by t3.FIELD    ;


							set cj= cj + 1 ;
							
					end while;
					
					
					set i = i+1;
					set nd = nd-1 ;
        end while;
	
   -- 关闭游标
   call tong_ji_lun_wen();
		
END;

