create
    definer = root@`%` procedure lunwen_province()
BEGIN
insert into ai_journal_article_managed_split(headline,pub_year,province)

select distinct a.headline,a.pub_year,a.province from
(select t1.headline,t1.pub_year,SUBSTRING_INDEX(SUBSTRING_INDEX(t1.province,', ',t2.help_topic_id+1),', ',-1) as province
from ai_journal_article_managed t1 left join mysql.help_topic t2 
on t2.help_topic_id < (LENGTH(t1.province)-LENGTH(REPLACE(t1.province,', ',''))+1)
where substr(FROM_UNIXTIME(TIMESTAMPS),1,10) between '2020-11-17' and '2020-11-18' and country like '%中国%' ) a;
END;

